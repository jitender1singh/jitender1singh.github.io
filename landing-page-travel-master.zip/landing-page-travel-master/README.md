# Travel Single Page - Personal project.

An example of single page for a travel agency or airline.

I wanted to test some functionalities such as registration and login buttons, scroll button to the top or slideshow with images.

It was made with HTML, CSS and javaScript and came to me as an idea from the Product landing page challenge of freeCodeCamp. 


![Travel Landing Page](https://res.cloudinary.com/drpcjt13x/image/upload/v1603025561/Proyectos/Product%20Landing%20Page/Landing_Page_Travel_Agency_odfiev.png "Travel Landing Page")


You can take a look at this project in [github](https://guacig.github.io/landing-page-travel/)

Also you can find the working demo in [codepen](https://codepen.io/GuaciG/full/eYOZeRO)

Feedback issues etc. are more than welcome! Thanks!
